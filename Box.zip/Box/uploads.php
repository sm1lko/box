<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>
 <script>
  Dropzone.options.myDropzone = {
    maxFilesize: 500,
    init: function() {
      this.on("uploadprogress", function(file, progress) {
        console.log("File progress", progress);
      });
    }
  }
</script>
</head>
<body>
<?php
session_start();
$ds= DIRECTORY_SEPARATOR;
 
$storeFolder = "files/".$_SESSION['username'];
 
if (!empty($_FILES)) {
    $tempFile = $_FILES['file']['tmp_name']; 
    $targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds; 
    $targetFile =  $targetPath. $_FILES['file']['name'];
    move_uploaded_file($tempFile,$targetFile);   
}
?>      
</body>
</html>
