<html>
<head>
<title>
Smail's Cloud
</title>
<link rel="stylesheet" type="text/css" href="index.css">
<meta charset='UTF-8'>
</head>
<body>
<?php 
	session_start();
	if(isset($_SESSION['username'])){//Če je že prijavljen, ga vržeš na main
		header("Location: main.php");
	}
?>
<div id="lepota">
Lepota je v notranjosti!
</div>

<div id="signin">
<form action="login.php" method="post">
	<input type='text' name='username' placeholder='Up. ime' required/><br>
	<input type='password' name='geslo' placeholder='geslo' required/><br><br>
	<input type='submit' name='login' value='Log in' required/><br>
</form>
<br>
</div>
<div id='signup'>
<form action="signup.php" method="post">
	<input type='text' name='ime' placeholder='ime' required/><br>
	<input type='text' name='priimek' placeholder='priimek' required/><br>
	<input type='text' name='username' placeholder='Up. ime' required/><br>
	<input type='password' name='geslo' placeholder='geslo' required/><br>
	<input type='password' name='geslo1' placeholder='ponovite geslo' required/><br>
	<input type='submit' name='signup' value='Sign up' required/>
</form>
<?php

?>
</body>
</html>
