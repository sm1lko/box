<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>
</head>
<body>

<?php
session_start();
if(isset($_POST['login'])&&!(isset($_SESSION['username']))){/*Če ni kliknu gumba, in ni prijavljen ga vrneš na index*/
	header("location: index.php");
}
if(isset($_SESSION['username'])){/*Če je že loginan ga pošlješ na main*/
	header("location: main.php");
}

else{//če pa ni, pa nadaljuješ z loginom.
	$link=mysqli_connect('localhost','root','','users') or die("Napaka pri povezovanju z bazo.");
	$query="select username from uporabnik where username='{$_POST['username']}'";
	$result=mysqli_query($link,$query);
	if(mysqli_num_rows($result)==0){echo "Vnešeni podatki so napačni, pobec.<br><a href='index.php'>Nazaj</a>";}
	else{
		$query="select username,geslo from uporabnik where username='{$_POST['username']}'";
		$result=mysqli_query($link,$query);	
		while($row=mysqli_fetch_assoc($result)){
			if($row['username']==$_POST['username']&&password_verify($_POST['geslo'],$row['geslo'])){
				//echo "Pozdravljen, ".$_POST['username']."."; //zgolj debug
				$_SESSION["username"]=$_POST["username"];
				echo $_SESSION["username"];
				header( "refresh:1;url=main.php" );
			}
			else if(($row['username']!=$_POST['username'])||($row['geslo']!=$_POST['geslo'])||($row['username']!=$_POST['username']&&$row['geslo']!=$_POST['geslo'])){
				echo "Vnešeni podatki so napačni.<br><a href='index.php'>Nazaj</a>";
			}
		}	
	}

	mysqli_close($link);
	}

?>
</body>
</html>

