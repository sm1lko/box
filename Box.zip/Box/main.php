<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>

<link href="dropzone.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="index.css">
 <script src="dropzone.js"></script>

</head>
<body>

<?php

session_start();
if(!isset($_SESSION['username'])){//Če session ni začet, ga vrneš na index
	header("refresh:1;url=index.php");
}
else{//če pa je, pa nadaljuješ.
?>

	<form action="uploads.php" class="dropzone">
	</form> 
	
	<form action='' method='post'>
		<input type='text' name='imenovemape' placeholder='Ime nove mape' required/><br>
		<input type='submit' value='Ustvari novo mapo' name='ustvarimapo' required/>
	</form>
	
<?php
	
	function berimapo($potdomape,$imemape,$zamik){
		echo "<b style=padding-left:{$zamik}em >".$imemape."</b><br>"; //zamik se bo z vsako rekurzijo večal---- lep izpis map
		$potdomape=$potdomape.$imemape;
		if ($handle = opendir($potdomape)){
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					if(is_dir($potdomape."/".$entry)){//Če je prebrana datoteka mapa...
						berimapo($potdomape."/",$entry,$zamik+1);
					}
					
					else{
						echo "<a style=padding-left:{$zamik}em href='{$potdomape}/{$entry}' download/><img src='/img/download.png'/></a>&nbsp; ";
						echo $entry." &nbsp;<a target='_blank' href='/files/{$_SESSION['username']}/{$entry}'><img src='/img/lupa.png'/></a>&nbsp; ";
						echo "<a href='?function=delete&filename=files/{$_SESSION['username']}/{$entry}'><img src='/img/brisi.jpg'/></a><br>";
					}
				}
			}
			closedir($handle);
		}
	}
	
	/*Prikazovanje njegovih file-ov*/
	$zamik=-1;
	if ($handle = opendir('files/'.$_SESSION['username'])) {

		$file_dir="files/".$_SESSION['username'];
		//echo "Directory handle:". $handle."<br>";
		echo "<a href='main.php'> Refresh </a><br>";
		echo "<br>Datoteke:<br>";
		if ($handle = opendir('files/'.$_SESSION['username'])) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					if(is_dir("files/"."{$_SESSION['username']}"."/"."{$entry}")){//Če je prebrana datoteka mapa...
						
						berimapo("files/"."{$_SESSION['username']}"."/","{$entry}",$zamik+1);
						
					echo "<br>";
					}
					
					else{
						echo "<a href='files/{$_SESSION['username']}/{$entry}' download/><img src='/img/download.png'/></a>&nbsp; ";
						echo $entry." &nbsp;<a target='_blank' href='/files/{$_SESSION['username']}/{$entry}'><img src='/img/lupa.png'/></a>&nbsp; ";
						echo "<a href='?function=delete&filename=files/{$_SESSION['username']}/{$entry}'><img src='/img/brisi.jpg'/></a><br>";
					}
				}
			}
			closedir($handle);
		}
		
	}
	
	if(isset($_GET['function'])){/*Zbriši file*/
		if(is_dir($_GET['filename'])){/*če je mapa*/
			rmdir($_GET['filename']);
			header("Refresh:0.1;url=main.php");
		}
		else{/*če je file*/
			unlink($_GET['filename']);
			header("Refresh:0.1;url=main.php");
		}
	}
	
	if(isset($_POST['ustvarimapo'])){
		mkdir("files/".$_SESSION['username']."/".$_POST['imenovemape']);
	}
	
	/*if(isset($_GET['action'])){ To je, names HTML5 download/ opcije. morš pa dodat main.php/?action=download&imefilea= pr download opciji. 
		echo $_GET['imefilea'];
		$file=$_GET['imefilea'];
		if (file_exists($file))	{
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
            ob_clean();//To je pomembn
			flush();//in to tud//Če ne, ne odpre slik
			readfile($file);
			exit;
		}
	}*/
}
?>
<div id="header">
Pozdravljen, <?php echo $_SESSION["username"]; ?>!
</div>

<div id="sporocilo">
Datoteke, ki jih brskalnik ne more prikazati, bodo avtomatično prenesene. 
</div>

<div id="footer">
<a href='odjava.php'>Odjava</a>
</div>
</body>
</html>
