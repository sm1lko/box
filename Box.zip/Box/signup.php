<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>
</head>
<body>
<?php
session_start();
if((isset($_SESSION['username']))){//Če je session začet, pomeni, da je uporabnik prijavljen in nima kaj tle delat!!
	header("location:index.php");
}
else{//Če pa ni, pa nadaljuješ z signupom.
	if(!(isset($_POST['signup']))){
		header("location:index.php");
	}
	else{
		if($_POST['geslo']!=$_POST['geslo1']){/*Preveri, če sta vpisani gesli enaki*/
			echo "Gesli se ne ujemata!<br>";
			echo "<a href='index.php'> Nazaj </a>";
		}
		else{ /*Preveri, če username že obstaja.*/
			$link=mysqli_connect("localhost","root",'',"users") or die("Napaka pri povezovanju z bazo.");
			$query="select username from uporabnik";
			$result=mysqli_query($link,$query);
			while($row=mysqli_fetch_assoc($result)){
				if($row['username']==$_POST['username']){
					echo "Uporabniško ime že obstaja. Prosim, izberite si drugo <br> <a href='index.php'> Nazaj</a>";
				}
			}
			//če username ne obstaja nadaljuješ z opisom
			$sol = [ 'cost' => 5];
			$hashgeslo=password_hash($_POST['geslo'],PASSWORD_BCRYPT,$sol);
			$query="insert into uporabnik(ime,priimek,username,geslo) values('{$_POST['ime']}','{$_POST['priimek']}','{$_POST['username']}','{$hashgeslo}')";
			
			if(mysqli_query($link,$query)){
				echo "Vpis uspešno dodan.";
				$file_dir="files/".$_POST['username'];
				if(!(file_exists($file_dir))){//Če mapa ne obstaja, jo narediš, drugače ne.
					mkdir($file_dir,0777);
				}
				header("refresh: 3;url=index.php");
			}
			else{
				echo "Vpis ni bil dodan.";
			}
			mysqli_close($link);			
		}
	}
}
?>
</body>
</html>
