<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>
</head>
<body>
<?php

?>
</body>
</html>
