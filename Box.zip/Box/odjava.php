<html>
<head>
<title>
Smail's Cloud
</title>
<meta charset='UTF-8'>
</head>
<body>
<?php
	session_start();
	session_unset();
	session_destroy();
	//echo "Hey";//Zgolj debug
	header("Location:index.php");
?>
</body>
</html>
